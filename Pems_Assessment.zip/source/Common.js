export const BaseUrl ='https://jsonplaceholder.typicode.com/';
